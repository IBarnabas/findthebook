export interface AuthorOfBook{
    name: string;
    key: string;
}