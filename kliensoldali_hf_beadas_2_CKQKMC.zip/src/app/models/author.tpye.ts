export interface Author {
    photos: number[];
    birth_date: string;
    name: string;
    bio: string;
    coversUrl: string[];
}