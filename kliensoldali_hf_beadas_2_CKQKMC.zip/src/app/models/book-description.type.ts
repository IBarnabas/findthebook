export interface BookDesc {
    description: string;
    key: string;
}

